module.exports = {
  i18n: {
    locales: ['en', 'ru'], // Добавьте нужные языки
    defaultLocale: 'ru',
  },
};
