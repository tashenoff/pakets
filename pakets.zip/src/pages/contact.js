import Banner from "../components/Banner";

export default function Contact() {
 
    return (
        <>
            <Banner
                backgroundImage="/contact.jpg"
                title='Контакты'

            />

            <div className="container mx-auto">
                <div className="py-5">
                    <p>ИП "Paketikz" ИИН 911122350042</p>
                    <p> Казахстан, г. Астана, ул. Аксай 11</p>
                    <p> тел.: +7 707 040 21 21 </p>
                    <p>e-mail: salespaketi@gmail.com</p>
                </div>

            </div>

            {/* <Banner
                backgroundImage="/footer.png"
                title='home_banner.title2'
                description='home_banner.description2'
                buttonText='home_banner.button2'
                onButtonClick={() => alert('home_banner.button2')}
            /> */}
        </>
    );
}

